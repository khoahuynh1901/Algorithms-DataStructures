
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Random;

class Node {
    public int data; 
    public Node next = null;    

    public Node(int data) {
        this.data = data;
    }
}

class MyLinkedList {
    // Head node of the LinkedList
    public Node head;
    
    //append mehtod to add a new node at the end of the list
    public void append(int data) {
        // Create a new node with the given data
        Node newNode = new Node(data);        
        // If the LinkedList is empty, set the head to the new node
        if (head == null) {
            head = newNode;
            return;
        }
        // Otherwise, traverse the LinkedList to find the last node
        Node last = head;
        while (last.next != null) {
            last = last.next;
        }
        // Set the next node of the last node to the new node
        last.next = newNode;
    }

    //insert a node by index
    public void insert(int index, int data) {
        // Create a new node with the given data
        Node newNode = new Node(data);        
        // If the LinkedList is empty, set the head to the new node
        if (head == null) {
            head = newNode;
            return;
        }
        // If the index is 0, insert the new node at the beginning of the list
        if (index == 0) {
            newNode.next = head;
            head = newNode;
            return;
        }
        // Otherwise, traverse the LinkedList to find the node at the given index
        Node prev = head;
        for (int i = 0; i < index - 1; i++) {
            // to avioid null pointer exception
            if (prev == null) {
                append(data);
                return;
            }
            prev = prev.next;
        }
        // Insert the new node after the node at the given index
        newNode.next = prev.next;
        prev.next = newNode;
    }

    //detect a node by key
    public void deleteByKey(int key) {
        //delete key [14]
        // If the LinkedList is empty, return
        if (head == null) {
            return;
        }
        // If the key is at the head of the list
        if (head.data == key) {
            head = head.next;
            return;
        }

        // Traverse the LinkedList to find the node with the given key
        Node prev = head;
        Node current = head.next;
        while (current != null && current.data != key) {
            prev = current;
            current = current.next;
        }

        // If the key was not found
        if (current == null) {
            System.out.println("Key not found in the list.");
            return;
        }

        prev.next = current.next;
    }


    public void reverse() {
    //your code here [3points]
        Node previousNode = null;
        Node currentNode = head;
        Node nextNode = null;

        while (currentNode != null) {
            nextNode = currentNode.next; // Store the next node
            currentNode.next = previousNode; // Reverse the pointer of the current node

            // Move pointers one position ahead
            previousNode = currentNode;
            currentNode = nextNode;
        }

        // Set the head to the last node
        head = previousNode;
    }
    

    public void printList() {
        Node n = head;
        while (n != null) {
            System.out.print(n.data + " ");
            n = n.next;
        }
        System.out.println();
    }
}


 public class Program_1 {

    public static void main(String[] args) {

    // Create a new LinkedList
    MyLinkedList list = new MyLinkedList();
    // Populate the list
    list.append(1);
    list.append(2);
    list.append(3);
    list.append(14);
    list.insert(3, 100);
    list.printList(); // 1 -> 2 -> 3 -> 100 -> 14

    // test 1: Reverse the list
    list.reverse();
    list.printList(); // 14 -> 100 -> 3 -> 2 -> 1

    // test 2: Remove 100 from the list
    list.deleteByKey(100);
    list.printList(); // 14 -> 3 -> 2 -> 1

    // test 3: Remove 14 from the list (14 is head of the list)
    list.deleteByKey(14);
    list.printList(); // 3 -> 2 -> 1

    //test 4: Remove 15 from list (15 does not exit in the list)
    list.deleteByKey(15);
    list.printList(); // 3 -> 2 -> 1
    
    }
}

